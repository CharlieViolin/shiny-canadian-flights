library(shiny)
library(ggplot2)
library(scales)

df <- readRDS("flight_category.rds")

ui <- fluidPage(
    titlePanel("Passenger Count by Year, Geography, and Flight Type"),

    sidebarLayout(
        sidebarPanel(
            selectInput("flight_type", "Flight Type", unique(df$flight_type)),
            sliderInput("year", label = "Years", value = c(2008, 2021),
                        min = 2008, max = 2021, sep = ""),
            checkboxGroupInput("geo", "Geography:",
                               unique(df$geo), selected = unique(df$geo))
        ),
        mainPanel(
            plotOutput("plot")
        )
    )
)

server <- function(input, output) {
    output$plot <- renderPlot({
        # Filter data based on user input
        df_subset <- df[df$geo %in% input$geo &
                            df$flight_type == input$flight_type, ]

        ggplot(df_subset, aes(year, passengers, color = geo)) +
            geom_line() + geom_point() +
            ggtitle(paste0("Passenger Count for ", input$flight_type,
                           " flights in Canada")) +
            xlab("Year") + ylab("Passenger Count") +
            scale_y_continuous(labels = unit_format(unit = "M", scale = 1e-6)) +
            scale_x_continuous(limits = c(input$year)) +
            theme(plot.title = element_text(size = 16, face = "bold"),
                  axis.title.y = element_text(size = 14, face = "bold"),
                  axis.title.x = element_text(size = 14, face = "bold"),
                  axis.text.y = element_text(size = 12),
                  axis.text.x = element_text(size = 12))
    })
}

shinyApp(ui = ui, server = server)
